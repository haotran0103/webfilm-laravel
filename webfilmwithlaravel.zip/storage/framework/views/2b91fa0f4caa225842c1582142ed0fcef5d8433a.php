

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
             <a class="btn btn-success col-12" href="<?php echo e(route('movie.index')); ?>">liệt kê phim</a>
            <div class="card">
                <div class="card-header"><?php echo e(__('danh sách loại')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(!isset($movie)): ?>
                        <?php echo Form::open(['route'=>'movie.store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                        <?php echo Form::open(['route'=>['movie.update',$movie->id],'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>
                    
                    <div class="form-group">
                        <?php echo Form::label('title', 'title', []); ?>

                        <?php echo Form::text('title', isset($movie) ? $movie->title :'', ['class'=>'form-control','placeholder'=>'nhập vào dữ liệu','id'=>'slug','onkeyup' => 'ChangeToSlug()']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('slug', 'slug', []); ?>

                        <?php echo Form::text('slug', isset($movie) ? $movie->slug :'', ['class'=>'form-control','placeholder'=>'nhập vào dữ liệu','id'=>'convert_slug']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('sotap', 'số tập phim', []); ?>

                        <?php echo Form::text('sotap', isset($movie) ? $movie->sotap :'', ['class'=>'form-control','placeholder'=>'nhập vào dữ liệu']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('thoiLuong', 'thời lượng', []); ?>

                        <?php echo Form::text('thoiLuong', isset($movie) ? $movie->thoiLuong :'', ['class'=>'form-control','placeholder'=>'nhập vào dữ liệu','id'=>'thoiLuong']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('description', 'description', []); ?>

                        <?php echo Form::textarea('description', isset($movie) ? $movie->description :'', ['class'=>'form-control','placeholder'=>'nhập vào dữ liệu','id'=>'description']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('trailer', 'Trailer', []); ?>

                        <?php echo Form::text('trailer', isset($movie) ? $movie->trailer :'', ['class'=>'form-control','placeholder'=>'nhập vào dữ liệu']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('tags', 'Tags', []); ?>

                        <?php echo Form::textarea('tags', isset($movie) ? $movie->tags :'', ['class'=>'form-control','placeholder'=>'nhập vào dữ liệu']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('category', 'category', []); ?>

                        <?php echo Form::select('category_id',$category,isset($movie)? $movie->category_id : '', ['class'=>'form-control']); ?>

                    </div>
                   <div class="form-group">
                        <?php echo Form::label('genre', 'genre: ', []); ?>

                        <?php $__currentLoopData = $list_genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($movie)): ?>
                            <?php echo Form::checkbox('genre[]', $gen->id,isset($movie_genre)&& $movie_genre->contains($gen->id)? true:false); ?>

                            <?php else: ?>
                            <?php echo Form::checkbox('genre[]', $gen->id); ?>

                            <?php endif; ?>
                            <?php echo Form::label('genre', $gen->title); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('Active', 'active', []); ?>

                        <?php echo Form::select('status',['1'=>'hiển thị','0'=>'không'],isset($movie)? $movie->status : '', ['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('resolution', 'quality', []); ?>

                        <?php echo Form::select('resolution',['0'=>'HD','1'=>'SD',2=>'FullHD'],isset($movie)? $movie->resolution : '', ['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('phuDe', 'Phụ đề', []); ?>

                        <?php echo Form::select('phuDe',['0'=>'phụ đề','1'=>'Thuyết minh',2=>'FullHD'],isset($movie)? $movie->phuDe : '', ['class'=>'form-control']); ?>

                    </div>
                    <div class="form-group">
                    <?php echo Form::label('image', 'image'); ?>

                    <?php echo Form::file('image', ['class'=>'form-control-file']); ?>

                    <?php if(isset($movie)): ?>
                        <img width="20%" src="<?php echo e(asset('uploads/movie/'.$movie->image)); ?>">
                    <?php endif; ?>
                </div>

                    <?php if(!isset($movie)): ?>
                        <?php echo Form::submit('Thêm dữ liệu', ['class'=>'btn btn-success']); ?>

                    <?php else: ?>
                         <?php echo Form::submit('Cập nhật dữ liệu', ['class'=>'btn btn-success']); ?>

                    <?php endif; ?>
                    
                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webfilmwithlaravel\resources\views/admincp/movie/form.blade.php ENDPATH**/ ?>