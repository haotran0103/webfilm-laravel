

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
             <a class="btn btn-success col-12" href="<?php echo e(route('episode.index')); ?>">liệt kê tập phim</a>
            <div class="card">
                <div class="card-header"><?php echo e(__('danh sách loại')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(!isset($episode)): ?>
                        <?php echo Form::open(['route'=>'episode.store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                        <?php echo Form::open(['route'=>['episode.update',$episode->id],'method'=>'PUT','enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>
                    
                    
                    <div class="form-group">
                        <?php echo Form::label('movie', 'chọn phim', []); ?>

                        <?php echo Form::select('movie_id',['0'=>'chọn phim','danh sách tên phim'=>$list_movie],isset($episode)? $episode->movie_id : '', ['class'=>'form-control select-movie']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('link', 'link phim', []); ?>

                        <?php echo Form::textarea('link', isset($episode) ? $episode->link :'', ['class'=>'form-control','placeholder'=>'nhập vào dữ liệu']); ?>

                    </div>
                    <?php if(!isset($episode)): ?>
                    <div class="form-group">
                        <?php echo Form::label('movie', 'tập phim', []); ?>

                        <select class="form-control" name="episode" id="episode_movie">
                            
                        </select>
                    </div>
                    <?php else: ?>
                    <div class="form-group">
                        <?php echo Form::label('episode', 'tập phim', []); ?>

                        <?php echo Form::text('episode', isset($episode) ? $episode->episode :'', ['class'=>'form-control','placeholder'=>'nhập vào dữ liệu','readonly']); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(!isset($movie)): ?>
                        <?php echo Form::submit('Thêm dữ liệu', ['class'=>'btn btn-success']); ?>

                    <?php else: ?>
                         <?php echo Form::submit('Cập nhật dữ liệu', ['class'=>'btn btn-success']); ?>

                    <?php endif; ?>
                    
                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webfilmwithlaravel\resources\views/admincp/episode/form.blade.php ENDPATH**/ ?>