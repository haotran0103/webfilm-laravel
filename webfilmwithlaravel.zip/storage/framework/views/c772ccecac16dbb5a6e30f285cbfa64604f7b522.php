

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
          <a class="btn btn-success col-12 justify-content-center" href="<?php echo e(route('movie.create')); ?>">thêm phim</a>
            <table class="table" id="tablefilm">
              <thead>
                <tr>
                  <th scope="col">id</th>
                  <th scope="col">title</th>
                  <th scope="col">slug</th>
                  <th scope="col">category</th>
                  <th scope="col">genre</th>
                  <th scope="col">image</th>
                  <th scope="col">status</th>
                  <th scope="col">quality</th>
                  <th scope="col">số Tập</th>
                  <th scope="col">ngày cập nhật</th>
                  <th scope="col">Thời lượng</th>
                  <th scope="col">season</th>
                  <th scope="col">Top Views</th>
                  <th scope="col">delete</th>
                  <th scope="col">update</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($movie->id); ?></th>
                  <td><?php echo e($movie->title); ?></td>
                  <td><?php echo e($movie->slug); ?></td>
                  <td><?php echo e($movie->category->title); ?></td>
                 
                  <td>
                     <?php $__currentLoopData = $movie->movie_genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <span class="badge badge-dark"><?php echo e($gen->title); ?></span>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </td>
                  
                  <td><img width="50%" src="<?php echo e(asset('uploads/movie/'.$movie->image)); ?>"></td>
                  <td>
                    <?php if($movie->status): ?>
                    hiển thị
                    <?php else: ?>
                    không hiển thị
                  <?php endif; ?>
                 </td>
                 <td>
                    <?php if($movie->resolution==0): ?>
                    HD
                    <?php elseif($movie->resolution==1): ?>
                    SD
                    <?php else: ?>
                    FullHD
                  <?php endif; ?>
                 </td>
                 <td><?php echo e($movie->sotap); ?></td>
                 <td><?php echo e($movie->ngayCapNhat); ?></td>
                 <td><?php echo e($movie->thoiLuong); ?></td>
                  <td>
                    <?php
                    $array = range(0, 30);
                    ?>
                     <?php echo Form::select('season', $array,isset($movie)? $movie->season : '', ['class'=>'select-season','id'=> $movie->id ]); ?>

                 </td>
                 <td>
                   <?php echo Form::select('topView', [0=>'Ngày',1=>'tuần',2=>'tháng',3=>'năm'], isset($movie)? $movie->topViews : '', ['class'=>'select-top-views','id'=> $movie->id ]); ?>

                 </td>
                 <td>
              <?php echo Form::open(['method'=>'DELETE','route'=>['movie.destroy',$movie->id],'onsubmit'=>'return confirm("xóa")']); ?>

              <?php echo Form::submit('Xóa', ['class'=>'btn btn-danger']); ?>

              <?php echo Form::close(); ?>

                 </td>
                 <td>
                     <a href="<?php echo e(route('movie.edit',$movie->id)); ?>" class="btn btn-warning">sửa</a>
                 </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webfilmwithlaravel\resources\views/admincp/movie/index.blade.php ENDPATH**/ ?>