

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
          <a class="btn btn-success col-12 justify-content-center" href="<?php echo e(route('episode.create')); ?>">thêm tập phim</a>
            <table class="table" id="tablefilm">
              <thead>
                <tr>
                  <th scope="col">tên phim</th>
                  <th scope="col">ảnh phim</th>
                  <th scope="col">tập phim</th>
                  <th scope="col">link</th>
                  
                  <th scope="col">delete</th>
                  <th scope="col">update</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $list_ep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <tr>
                  <td><?php echo e($mov->movie->title); ?></td>
                  <td><img style="width: 50%; height: 50%" src="<?php echo e(asset('uploads/movie/'.$mov->movie->image)); ?>"></td>
                  <td><?php echo e($mov->episode); ?></td>
                  <td style="width: 30% ;height:30%"><?php echo $mov->link; ?></td>

                 <td>
              <?php echo Form::open(['method'=>'DELETE','route'=>['episode.destroy',$mov->id],'onsubmit'=>'return confirm("xóa")']); ?>

              <?php echo Form::submit('Xóa', ['class'=>'btn btn-danger']); ?>

              <?php echo Form::close(); ?>

                 </td>
                 <td>
                     <a href="<?php echo e(route('episode.edit',$mov->id)); ?>" class="btn btn-warning">sửa</a>
                 </td>
                </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webfilmwithlaravel\resources\views/admincp/episode/index.blade.php ENDPATH**/ ?>